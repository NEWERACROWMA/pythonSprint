equipes = [
    'Mahindra Racing', 'Jaguar TCS Racing', 'Maserati MSG Racing', 'Nissan Formula E Team'
]

Mahindra_corredores = [
    'Edoardo Mortara', 'Nyck De Vries'
]

Jaguar_corredores = [
    'Mitch Evans', 'Nick Cassidy'
]

Maserati_corredores = [
    'Maximilian Gunther', 'Jehan Daruvala'
]

Nissan_corredores = [
    'Oliver Rowland', 'Sacha Fenestraz'
]
